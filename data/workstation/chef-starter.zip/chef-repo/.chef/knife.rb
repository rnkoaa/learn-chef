# See http://docs.chef.io/config_rb_knife.html for more information on knife configuration options

current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "richard_agyei"
client_key               "#{current_dir}/richard_agyei.pem"
chef_server_url          "https://api.chef.io/organizations/rnkoaa"
cookbook_path            ["#{current_dir}/../cookbooks"]
